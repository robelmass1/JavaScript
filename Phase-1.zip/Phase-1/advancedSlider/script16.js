$(window).on('load',function() {
    $('.flexslider').flexslider(
        {
            animation:'slide',
            slideshowSpeed:2000,
            /* direction:'vertical', */
            reverse:true,
            pauseOnHover:true,
            touch:true,
            animationSpeed: 600
    
       }
    );
  });