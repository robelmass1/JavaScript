
$('nav ul li a').click(function(){
    var thisSection=$(this).attr('href');
    var thisLink=$(this);
   /*  alert(thisSection); */
   $('html').stop().animate({
        scrollTop:$(thisSection).offset().top
    },800,'easeOutCirc',function(){
    // $('nav ul li a').removeAttr('class'); // remove previously clicked add 
    // $(thisLink).addClass('selected');// we can also use attr method ... highlight the new class clicked 
    });// we animate over 800ms 
    
    /*  stop helps us to animate the thing on the section we choose after we make a command and want to make
     a change later then stop makes it to stop at that specific section.
       $('html').stop().animate({scrollTop:$(thisSection).offset().top-100},2000);
     top-100 makes it to stop 100 px down the top */

     return false; // work as event prevent default
});

// all contents of page are loaded at the begining
// These below are related with scrolling the page 
$(window).on('load',function(){
    var allLinks=$('nav ul li a');
    var posts=$('section');
    var pageTop;
    var postPos;
    var counter=0;
    var previousCount=0;
    var doneResizing;
   
    var postTops=[];
    resetPagePosition();     // This function runs when the page loads

   /*  posts.each(function(){
        postTops.push(Math.floor($(this).offset().top));
    }); 

    console.log(postTops);  */
   
    $(window).scroll(function(){
       /*  console.log('scrolling'); */
       /* postPos=$(posts[0]).offset().top;// get 1 st section on the page and get its offset top
       pageTop=$(window).scrollTop();// get window scroll top
       console.log(`${pageTop} and ${postPos}`); */
       pageTop=$(window).scrollTop()+100;
       if(pageTop>postTops[counter+1]){
            counter++;
           /*  console.log(`Scrolling down: ${counter}`); */
       }

       else if(counter>0 && pageTop<postTops[counter]){
            counter--;
           /*  console.log(`Scrolling Up: ${counter}`); */
       }
       // --^ Clear all the others and makes the one we scrolled to be highlighted.
       if(counter!=previousCount){
          $(allLinks).removeAttr('class');
          $('nav ul li a').eq(counter).addClass('selected');// eq is equal in jQuery
          previousCount=counter;
       }              
       
    });

    $(window).on('resize',function(){
        /* console.log('resizing'); */
        clearTimeout(doneResizing);
        doneResizing=setTimeout(function(){
            resetPagePosition();              // This function runs again when we do resize
            
        },500);
    });

function resetPagePosition(){
    postTops=[];
    posts.each(function(){
        postTops.push(Math.floor($(this).offset().top));
    });
    /*  console.log(postTops);  */// tells after we finish resizing instead of telling each time

    // this down relates to issues of refereshing our page
    var pagePosition=$(window).scrollTop()+100;
    counter=0;
    for(var i=0;i<postTops.length;i++){
        if(pagePosition=postTops[i]){
            counter++;
        }

        counter--;

        $(allLinks).removeAttr('class');
        $('nav ul li a').eq(counter).addClass('selected');
    }

}
});
