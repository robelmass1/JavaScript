
(function(){
    'use strict';
    const detailsForm=document.querySelector('#destination_details_form');
    detailsForm.addEventListener('submit',handleFormSubmit);

    function handleFormSubmit(event) {
        event.preventDefault();
        const destName=document.getElementById('name').value;
        const destLocation=document.getElementById('location').value;
        const destPhoto=document.getElementById('setPhoto').value;
        const destDesr=document.getElementById('description').value; 
        
        // Clear form fields
        detailsForm.reset();
        
        // Create or add the card here
        const destCard=createDestinationCard(destName, destLocation, destPhoto, destDesr);
    
        // Update title if container is empty
        const wishListContainer=document.getElementById('destination_container');
        if(wishListContainer.children.length==0){
            document.getElementById('title').innerHTML='My destination plan list';
        }
    
        // Append card to container
        wishListContainer.appendChild(destCard);
       };
       
       function createDestinationCard(name, location, photoURL, desc) {
            const card=document.createElement('div');
            card.className='card';
    
            const img=document.createElement('img');
            img.setAttribute('alt',name);
            const constantPhotoUrl='C:/Users/rkass/Documents/Programming/JavaScript/Entry/image/sydney.jpg';
            img.setAttribute('src', photoURL.length === 0 ? constantPhotoUrl : photoURL);
            /* img.setAttribute('src',photoURL.length===0? constantPhotoUrl:photoURL); */
    
            card.appendChild(img);
    
            const cardBody=document.createElement('div');
            cardBody.className='card-body';
    
            const cardTitle=document.createElement('h3');
            cardTitle.innerText=name;
            cardBody.appendChild(cardTitle);
    
            const cardSubTitle=document.createElement('h4');
            cardSubTitle.innerText=location;
            cardBody.appendChild(cardSubTitle);
    
            if(desc.length !== 0){
                const cardText=document.createElement('p');
                cardText.className='card-text';
                cardText.innerText=desc;
                cardBody.appendChild(cardText);
            }
    
            const cardDelateBtn=document.createElement('button');
            cardDelateBtn.innerText="Remove";
            cardDelateBtn.addEventListener('click',removeDestination);
            cardBody.appendChild(cardDelateBtn);
    
            card.appendChild(cardBody);
    
            return card;
       }
    
       function removeDestination(event){
            const card = event.target.parentElement.parentElement;
            card.remove();
        }
    
   

}());

